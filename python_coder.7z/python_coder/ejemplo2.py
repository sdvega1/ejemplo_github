import sys
print(f"NOMBRE: {sys.argv[1]} \n\n")

print(f"EDAD: {sys.argv[2]} \n\n")


print(f"PESO: {sys.argv[3]} \n\n")

