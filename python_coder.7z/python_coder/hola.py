
print("hola mundo, el primer script que hago")

# C:\Users\garumani\Downloads\presentacion_coder\python_coder\hola.py