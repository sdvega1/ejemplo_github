def sumar(n1, n2):
    print (f"La suma me da: {n1+n2}")

def restar(n1, n2):
    print (f"La resta me da: {n1-n2}")