import funciones_matematicas #form carpeta/funciones_matematicas 
from atleta import *


funciones_matematicas.sumar(4,11)

funciones_matematicas.restar(5,2)





atleta_nuevo = TriAtleta("Mariposa", "500", "Urbano", "BMX", "Nicolas Perez", 31)

print(f"{atleta_nuevo}")