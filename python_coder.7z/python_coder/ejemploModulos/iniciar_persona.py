from persona import *

gabo = Persona("Gabriel", "Rumani")

gabo.hablar()