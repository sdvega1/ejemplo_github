from setuptools import setup

setup(


    name="mi_primer_paquete",
    version = "1.0",
    description = "Estamos haciendo el primer paquete distribuido",
    author = "Clase 14 CODER - Python",
    author_email ="coder@coder.com",

    packages= ["mi_primer_paquete"]


)